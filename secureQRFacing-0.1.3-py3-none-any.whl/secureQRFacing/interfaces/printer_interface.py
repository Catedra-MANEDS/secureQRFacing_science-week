# This file contains the printer interface specification.
# The printer interface is responsible for defining operations upon
# writing certain data into, for instance, QR codes.

from abc import ABC, abstractmethod

class PrinterInterface(ABC):

    @abstractmethod
    def init_backend(self):
        '''Initializes the backend for the printer.
        '''
        pass

    @staticmethod
    @abstractmethod
    def print(data: list, path: str,
            version: int, error_correction: str):
        '''Writes the data into a QR code at the given path.
        '''
        pass

