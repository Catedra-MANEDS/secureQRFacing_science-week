from .models.qr_scanner import QRScanner
from .models.qr_printer import QRPrinter
from .models.face_scanner import FaceScanner
from .models.autoencoder import Autoencoder
from . import encoder, decoder
from bitstring import BitArray
import numpy as np
import os
from enum import Enum

class Models(Enum):
    """
    Enum class for the different latent sizes.
    """
    LATENT16 = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'models',
        'weights',
        'single-latent16.h5'
    )

class SecureQRFacing():

    def __init__(self, model_path: Models = Models.LATENT16):
        self.model_path = model_path.value
        
    def represent(
            self, image_path: str, stage: int = 1,
            backend: str = "Facenet", autoencoder_path: str = None,
            verbose: int = 0
    ) -> None:
        """
        Generates a QR code from the face image. (Currently only supports images with a single face).

        Args:
            image_path (str): The path to the image to be encoded.
            stage (int): The stage of the encoding process. Defaults to 0.
                - 0: The face embedding is directly obtained from the model.
                - 1: The face embedding is outputted in the latent representation.
                - 2: The face embedding is reconstructed from the latent representation.
            backend (str): The backend to be used for face detection. Defaults to "Facenet".
            autoencoder_path (str): The path to the autoencoder to be used for encoding the information. Defaults to './models/weights/single-latent16.h5'.
            decimal_positions (int): Defaults to 3. The number of decimal positions to be used for encoding.
            float_length (int): Defaults to 32. The length of the float to be used for encoding.
            verbose (int): The verbosity of the encoding process. Defaults to 0.

        Returns:

            None
        """

        if stage not in [0, 1, 2]:
            raise ValueError("Invalid stage. Choose one of the following: 0, 1, 2.")

        if autoencoder_path is None: autoencoder_path = self.model_path

        face_scanner = FaceScanner()
        autoencoder = Autoencoder(path=autoencoder_path)
        faces = face_scanner.scan(image_path, backend=backend, verbose=verbose)[0]
        
        if stage == 0:
            return faces
        if stage == 1:
            return autoencoder.encode(faces)
        return autoencoder.predict(faces)

    def generate(
            self, image_path: str, qr_path: str,
            backend: str = "Facenet", autoencoder_path: str = None,
            decimal_positions: int = 3, float_length: int = 32, verbose: int = 0
    ) -> None:
        """
        Generates a QR code from the face image. (Currently only supports images with a single face).

        Args:
            image_path (str): The path to the image to be encoded.
            qr_path (str): The path to the QR code to be generated.
            backend (str): The backend to be used for face detection. Defaults to "Facenet".
            autoencoder_path (str): The path to the autoencoder to be used for encoding the information. Defaults to './models/weights/single-latent16.h5'.
            decimal_positions (int): Defaults to 3. The number of decimal positions to be used for encoding.
            float_length (int): Defaults to 32. The length of the float to be used for encoding.
            verbose (int): The verbosity of the encoding process. Defaults to 0.

        Returns:

            None
        """

        if autoencoder_path is None: autoencoder_path = self.model_path


        face_scanner = FaceScanner()
        autoencoder = Autoencoder(path=autoencoder_path)
        qr_printer = QRPrinter()

        faces = face_scanner.scan(image_path, backend=backend, verbose=verbose)[0]
        reduced_faces = autoencoder.encode(faces)
        encoded_bistream = encoder.pack(reduced_faces, decimal_positions=decimal_positions, float_length=float_length)
        qr_printer.print(encoded_bistream, qr_path, verbose=verbose)


    def retrieve(self, qr_code_path: str,
                is_latent: bool=False,
                decimal_positions: int=3,
                float_length: int=32,
                autoencoder_path = None,  
                qr_scanner_backend: str = 'zxing-https') -> np.array:
        """
        Retrieves the embedding of the face from the QR code.

        Args:
            qr_code_path (str): The path to the QR code image.
            is_latent (bool): Defaults to 'False'. Whether the retrieved data is a latent representation or not.
            decimal_positions (int): Defaults to 3. The number of decimal positions to be used for encoding.
            float_length (int): Defaults to 32. The length of the float to be used for encoding.
            model_path (str): The path to the autoencoder to be used for decoding the information.
            qr_scanner (str): The backend to be used for scanning QRs. Defaults to "zxing-https".

        Returns:
            np.array: The retrieved face embedding.
        """

        if autoencoder_path is None: autoencoder_path = self.model_path


        qr_scanner = QRScanner.get_scanner(qr_scanner_backend)
        qr_code = decoder.unpack(qr_scanner.scan(qr_code_path), decimal_positions, float_length)

        if is_latent: return qr_code
        ae = Autoencoder(path=autoencoder_path)
        return ae.decode(qr_code)
