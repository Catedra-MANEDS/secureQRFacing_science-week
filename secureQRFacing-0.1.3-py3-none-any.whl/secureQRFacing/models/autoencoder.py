import tensorflow as tf
import keras
from keras import layers
import numpy as np

def linear(x, slope=1):
    return x*slope

def cosine_loss(y_true, y_pred):

    y_pred_normalised = keras.backend.l2_normalize(y_pred, axis=-1)
    dot_prod = tf.reduce_sum(y_true*y_pred_normalised, axis = 1)
    return 1 - dot_prod

def l2_normalised_metric(y_true, y_pred):
    """
    Calculate the L2 distance between the true and predicted values,
    after L2-normalizing the predicted values.

    Parameters:
    y_true -- tensor of true values
    y_pred -- tensor of predicted values

    Returns:
    L2 distance -- tensor of L2 distance between normalized predictions and true values
    """
    y_pred_normalised = keras.backend.l2_normalize(y_pred, axis=-1) #L2-normalise the predicted values
    l2_distance = keras.backend.sqrt(keras.backend.sum(keras.backend.square(y_true - y_pred_normalised), axis=-1))
    return l2_distance

class Autoencoder():

    def __init__(self, path = None):

        if path:
            self.load_model(path)
        else:
            self.generate_model()

        if not hasattr(self, 'latent_dims'):
            raise AttributeError('latent_dims attribute not found')

    def generate_model(self, input_shape: int = 128, latent_dims: int = 16):
        
        input_shape = (input_shape)

        # Encoder
        encoder_input = keras.Input(shape=input_shape)
        encoded = layers.Dense(latent_dims, activation='relu')(encoder_input)

        # Decoder
        decoded = layers.Dense(input_shape, activation=linear)(encoded)

        autoencoder = keras.Model(encoder_input, decoded)
        autoencoder.compile(optimizer='adam', loss=[cosine_loss], metrics=[l2_normalised_metric])

        self.latent_dims = latent_dims
        self.model = autoencoder
        self.encoder = keras.Model(inputs=self.model.input, outputs=self.model.layers[1].output)
        self.decoder = keras.Model(inputs=self.model.layers[2].input, outputs=self.model.layers[2].output)
    
    def load_model(self, model_path: str):

        self.model = keras.models.load_model(model_path,
            custom_objects={'cosine_loss': cosine_loss, 'l2_normalised_metric': l2_normalised_metric, 'linear': linear})
        self.latent_dims = self.model.layers[-2].output_shape[1]
        self.encoder = keras.Model(inputs=self.model.input, outputs=self.model.layers[1].output)
        self.decoder = keras.Model(inputs=self.model.layers[2].input, outputs=self.model.layers[2].output)

    def save_model(self, model_path: str):

        self.model.save(model_path)

    def encode(self, data: list) -> list:

        data = np.array(data).reshape(-1,128)
        return self.encoder.predict(data)
    
    def decode(self, data: list) -> list:

        data = np.array(data).reshape(-1, self.latent_dims)
        return self.decoder.predict(data)
    
    def predict(self, data: list) -> list:

        data = np.array(data).reshape(-1,128)
        return self.model.predict(data)