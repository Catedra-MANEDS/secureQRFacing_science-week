from ..interfaces.scanner_interface import ScannerInterface
import os
import numpy as np
from bitstring import BitArray

class QRScanner():
    """
    Factory class for QR code scanning.
    """

    @staticmethod
    def get_scanner(backend: str = "zxing-https"):
        """
        Returns a QR code scanner object.

        Args:
        - backend: The backend to be used for scanning. Defaults to "zxing-https".

        Returns:
        - A QR code scanner object.
        """

        backend = backend.lower()
        if backend == "zxing-https":
            return QRScannerZXingHttps()
        else:
            raise ValueError("Invalid backend. Choose one of the following: zxing-https.")

class QRScannerZXingHttps(ScannerInterface):

    def __init__(self):
        self.init_backend()

    def init_backend(self):
        import cv2
        import cairosvg
        import requests
        import regex
        from pdf2image import convert_from_path
        self.svg_engine = cairosvg
        self.image_engine = cv2
        self.decoder = requests.post
        self.re = regex
        self.url = "https://zxing.org/w/decode"
        self.pdf_engine = convert_from_path

    def scan(self, image_path: str, verbose: int = 0):
        """
        Scans the image at the given path.
        Reads the QR code within the image and returns the data.
        
        Args:
        - image_path: The path to the image to be scanned.
        - verbose: The verbosity of the scanning process. Defaults to 0.

        Returns:
        - BitArray: The data read from the QR code.

        """
        return self._scan_raw(image_path, verbose)
    
    def _scan_raw(self, image_path: str, verbose: int = 0):
        """
        Scans the image at the given path.
        Reads the QR code within the image and returns the data.

        Args:
        - image_path: The path to the image to be scanned.
        - verbose: The verbosity of the scanning process. Defaults to 0.

        Returns:
        - The data read from the QR code.
        """

        if image_path.split('.')[-1].lower() not in ['svg', 'png', 'pdf', 'jpg', 'jpeg', 'webp']:
            raise ValueError("Invalid image format. Choose one of the following: svg, png, pdf, jpg, jpeg, webp.")

        png_path = None
        if image_path.endswith(".svg"):
            png_path = image_path.replace(".svg", ".png")
            self.svg_engine.svg2png(url=image_path, write_to=png_path,
                                    background_color='#FFFFFF', scale=2)
            image_path = png_path

        if image_path.endswith(".pdf"):
            png_path = image_path.replace(".pdf", ".png")
            images = self.pdf_engine(image_path)
            images[0].save(png_path, 'PNG')
            image_path = png_path

        image = self.image_engine.imread(image_path)
        image = self.image_engine.cvtColor(
            image, self.image_engine.COLOR_BGR2GRAY
        )

        detector = self.image_engine.QRCodeDetector()
        success, points = detector.detect(image)

        if not success:
            raise ValueError("No QR code found in the image.")

        # Save the cropped and aligned image
        x, y, w, h = self.image_engine.boundingRect(points)
        cropped_qr_code = image[y:y+h, x:x+w]
        _, png_data = self.image_engine.imencode('.png', cropped_qr_code)

        # Send the image to the decoder

        data = self.decoder(self.url, files={"f": png_data.tobytes()})


        if png_path: os.remove(png_path) # Remove the temporary file.

        if verbose:
            print(f"Scanning image at {image_path}.")
            print(f"Data: {data.text}")

        return self.process(data)

    def process(self, data) -> BitArray:
        """
        Gets the hex string from the received response.
        """
        
        # First nibble is the mode indicator. Should always be 4 in this case.
        # Next byte is the character count indicator. Should be 0x24 for decimal_positions=4
        # and 0x1c for decimal_positions=3.

        data = self.re.findall(r'(?<=<pre>)(.*?)(?=<\/pre>)', data.text, self.re.DOTALL)[1]
        payload = BitArray(hex=data.replace('\n', '').replace(' ', ''))
        data_length = payload[4:12].uint

        return payload[12:12+data_length*8]