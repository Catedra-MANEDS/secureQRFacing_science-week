# This file contains the decoder class for the secureQRFacing module
# The decoder class is responsible for decoding the data from the QR code.

from bitstring import BitArray
import numpy as np
import math

LOG2_10 = 3.3219280948873626

# TODO: Tests for this function are missing
def decode_into_bitarray(int_list: list) -> BitArray:
    
    bitstring_list = [BitArray(uint=x, length=8) for x in int_list]
    return BitArray().join(bitstring_list)

def decode_from_bitstring(bitstring: BitArray, decimal_positions=3) -> list:
    '''Decodes the data from a bitstring.
    The input is a bitstring representing the encoding.
    The bitstring is decoded into a list of numbers.

    Preconditions: decimal_positions > 0.
    '''
    min_needed_bits = math.ceil(LOG2_10 * decimal_positions)

    if len(bitstring) % (2 + min_needed_bits) != 0: raise ValueError("Input cannot be interpreted as a valid encoding")

    components = [component for component in bitstring.cut(2 + min_needed_bits)]

    for index, component in enumerate(components):

        sign = 1
        if component[1]:
            sign = -1

        append_int = '0.'
        if component[0]:
            component = BitArray(uint=1, length=2+min_needed_bits)
            append_int = ''

        fractional_part = str(component[-min_needed_bits:].uint)

        append_leading_zeros = '0'*(decimal_positions - len(fractional_part))

        components[index] = sign * float(append_int + append_leading_zeros + fractional_part)

    return components

def decode_from_int_list(int_list : list, decimal_positions=3, decimal_separator="."):
    '''Decodes the data from a list of integers.
    The input is a list of integers representing the bitstring.
    The integers are converted to a bitstring and then decoded.

    Preconditions: decimal_positions > 0.
                    input is a valid encoding, i.e. divisible by 8.
    '''
    min_needed_bits = math.ceil(LOG2_10 * decimal_positions)
    bitstring_list = [BitArray(uint=x, length=8) for x in int_list]
    bitstring = BitArray().join(bitstring_list)

    if len(bitstring) % (2 + min_needed_bits) != 0: raise ValueError("Input cannot be interpreted as a valid encoding")

    components = [component for component in bitstring.cut(2 + min_needed_bits)]

    for index, component in enumerate(components):

        sign = 1
        if component[1]:
            sign = -1

        append_int = '0.'
        if component[0]:
            component = BitArray(uint=1, length=2+min_needed_bits)
            append_int = ''

        fractional_part = str(component[-min_needed_bits:].uint)

        append_leading_zeros = '0'*(decimal_positions - len(fractional_part))

        components[index] = sign * float(append_int + append_leading_zeros + fractional_part)

    return components

def unpack(payload: BitArray, decimal_positions=3, float_length = 32) -> list:
    """
    This method unpacks the payload from the QR code retrieving the original data.
    """
    float_part = payload[0:float_length]
    components = payload[float_length:]

    float_num = float_part.float

    components = decode_from_bitstring(components,
                                    decimal_positions=decimal_positions)
    
    return float_num*np.array(components)





    
