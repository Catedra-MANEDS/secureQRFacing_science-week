import unittest
import sys
from deepface import DeepFace
import numpy as np
import os

sys.path.append('/home/ssierra/Projects/secureQRFacing/src')
from secureQRFacing.secureqrfacing import SecureQRFacing
from secureQRFacing.models.autoencoder import Autoencoder


class TestSecureqrfacing(unittest.TestCase):

    def test_represent(self):

        # Arrange
        image_path = "./tests/testing_resources/hayden.jpg"

        # Act
        expected = DeepFace.represent(image_path, model_name="Facenet")[0]['embedding']
        expected = expected / np.linalg.norm(expected)
        sqf = SecureQRFacing()
        result = sqf.represent(image_path, 0)

        # Assert
        self.assertEqual(np.linalg.norm(result - expected), 0)

    def test_represent_latent(self):

        # Arrange
        image_path = "./tests/testing_resources/hayden.jpg"
        ae = Autoencoder('./src/secureQRFacing/models/weights/single-latent16.h5')

        # Act
        expected = DeepFace.represent(image_path, model_name="Facenet")[0]['embedding']
        expected = expected / np.linalg.norm(expected)
        expected = ae.encode(expected)
        
        sqf = SecureQRFacing()
        result = sqf.represent(image_path)

        # Assert
        self.assertEqual(np.linalg.norm(result - expected), 0)

    def test_represent_reconstruct(self):

        # Arrange
        image_path = "./tests/testing_resources/hayden.jpg"
        ae = Autoencoder('./src/secureQRFacing/models/weights/single-latent16.h5')

        # Act
        expected = DeepFace.represent(image_path, model_name="Facenet")[0]['embedding']
        expected = expected / np.linalg.norm(expected)
        expected = ae.predict(expected)
        
        sqf = SecureQRFacing()
        result = sqf.represent(image_path, 2)

        # Assert
        self.assertEqual(np.linalg.norm(result - expected), 0)

    def test_generate(self):

        # Arrange
        image_path = "./tests/testing_resources/hayden.jpg"
        qr_path = "./tests/testing_resources/test_sqf.svg"

        # Act
        sqf = SecureQRFacing()
        sqf.generate(image_path, qr_path)

        # Assert
        self.assertTrue(os.path.exists(qr_path))

    def test_retrieve(self):

        # Arrange
        qr_code_path = "./tests/testing_resources/test_sqf.svg"

        # Get expected 
        sqf = SecureQRFacing()
        expected = sqf.represent("./tests/testing_resources/hayden.jpg", 2)

        # Act
        result = sqf.retrieve(qr_code_path)

        # Assert
        self.assertTrue(np.linalg.norm(result - expected) < 0.01)

    def test_gen_with_no_face(self):

        # Arrange
        image_path = "./tests/testing_resources/no_face.png"
        qr_path = "./tests/testing_resources/test_no_face_sqf.svg"

        # Act
        sqf = SecureQRFacing()

        try:
            sqf.generate(image_path, qr_path)
        except Exception as e:

            # Assert
            self.assertTrue(isinstance(e, ValueError))

if __name__ == '__main__':
    unittest.main()