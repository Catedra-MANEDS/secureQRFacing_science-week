import unittest
import sys
from bitstring import BitArray

sys.path.append('/home/ssierra/Projects/secureQRFacing/src')
from secureQRFacing import encoder

class TestEncoder(unittest.TestCase):

    def test_encode_from_string(self):
        # Arrange
        str_embedding = "[-1.325,0.456,1.78,-0.2, 1.25]"
        expected = [[True,"0"], [False, "456"], [False, "2"], [True, "200"], [False, "4"]]

        # Act
        result = encoder.encode_from_string(str_embedding)
        result = [[x[1], str(x[2:].uint)] for x in result]

        # Assert
        self.assertEqual(result, expected)

    def test_encode_component_from_string(self):
        # Arrange
        str_component = ["-0.325", "0.021", "0.4", "0.004104567", "0.0001", "-1.456"]
        expected = [[True, 325], [False, 21], [False, 400], [False, 4], [False, 0], [True, 0]]

        # Act
        result = [encoder.encode_component_from_string(x) for x in str_component]
        result = [[x[1], x[2:].uint] for x in result]

        # Assert
        self.assertEqual(result, expected)

    def test_encode_component(self):

        # Arrange
        component = [-0.325, 0.021, 0.4, -0.004104567, 0.0001, -1.456, 1.52]
        expected = [[True, 325], [False, 21], [False, 400], [True, 4], [False, 0], [True, 0], [False, 0]]

        # Act
        result = [encoder.encode_component(x) for x in component]
        result = [[x[1], x[2:].uint] for x in result]

        # Assert
        self.assertEqual(result, expected)

    def test_encode(self):

        # Arrange
        embedding = [-0.325, 0.021, 0.4, -0.004104567, 0.0001, -1.456, 1.20]
        expected = [[True, 325], [False, 21], [False, 400], [True, 4], [False, 0], [True, 5], [False, 6]]

        # Act
        result = encoder.encode(embedding)
        result = [[x[1], x[2:].uint] for x in result]

        # Assert
        self.assertEqual(result, expected)
        self.assertRaises(ValueError, encoder.encode, [-3.1415, 3.1415]) # Test for invalid input.

    def test_to_int_list(self):
        # Arrange
        str_embedding = "-0.325, 0.021, 0.4, -0.004104567, 0.0001, -1.456"
        expected = [84, 80, 21, 25, 4, 4, 0, 12, 5]

        # Act
        result = encoder.encode_from_string(str_embedding)
        result = encoder.to_int_list(encoder.join(encoder.encode_from_string(str_embedding)))

        # Assert
        self.assertEqual(result, expected)

if __name__ == "__main__":
    unittest.main()