import unittest
import sys
from deepface import DeepFace

sys.path.append('/home/ssierra/Projects/secureQRFacing/src')
from secureQRFacing.models.face_scanner import FaceScanner

class TestFaceScanner(unittest.TestCase):
    
    def test_scan(self):

        # Arrange
        face_scanner = FaceScanner()
        image_path = "/home/ssierra/Projects/secureQRFacing/tests/testing_resources/hayden_ewan.webp"
        expected = DeepFace.represent(image_path, model_name="Facenet")

        # Act
        result = face_scanner.scan(image_path, embedding_only=False, normalise=False)
        
        # Assert
        self.assertEqual(result, expected)

if __name__ == '__main__':
    unittest.main()