import unittest
import sys
from bitstring import BitArray

sys.path.append('/home/ssierra/Projects/secureQRFacing/src')
from secureQRFacing import encoder, decoder

class TestDecoder(unittest.TestCase):

    def test_decode_from_int_list(self):
        # Arrange
        # Arrange
        str_embedding = "-0.325, 0.021, 0.4, -0.004104567, 0.0001, -1.456, 1.53, -0.52"
        expected_encoding = [84, 80, 21, 25, 4, 4, 0, 12, 5, 128, 102, 8]
        expected_decoding = [-0.325, 0.021, 0.4, -0.004, 0.000, -1, 1, -0.52]

        # Act
        result_encoding = encoder.encode_from_string(str_embedding)
        result_encoding = encoder.to_int_list(encoder.join(encoder.encode_from_string(str_embedding)))

        result_decoding = decoder.decode_from_int_list(result_encoding)

        # Assert
        self.assertEqual(result_encoding, expected_encoding)
        self.assertEqual(result_decoding, expected_decoding)

if __name__ == '__main__':
    unittest.main()