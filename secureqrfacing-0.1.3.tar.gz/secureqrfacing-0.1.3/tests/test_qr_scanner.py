import unittest
import sys
import numpy as np
from bitstring import BitArray

sys.path.append('/home/ssierra/Projects/secureQRFacing/src')
from secureQRFacing.models.qr_scanner import QRScanner
from secureQRFacing.models.qr_printer import QRPrinter
from secureQRFacing.models.face_scanner import FaceScanner
from secureQRFacing.models.autoencoder import Autoencoder
from secureQRFacing import encoder, decoder

class TestQRScanner(unittest.TestCase):

    def test_scan(self):

        # Arrange
        qr_scanner = QRScanner.get_scanner("zxing-https")
        image_path = "/home/ssierra/Projects/secureQRFacing/tests/testing_resources/test_pass.pdf"
        expected = "maspass"

        # Act
        result = qr_scanner.scan(image_path).bytes.decode("utf-8")

        # Assert
        self.assertEqual(result, expected)

    def test_scan_invalid_image(self):
            
        # Arrange
        qr_scanner = QRScanner.get_scanner("zxing-https")
        image_path = "/home/ssierra/Projects/secureQRFacing/tests/testing_resources/test_.pass.txt"

        # Act
        with self.assertRaises(ValueError):
            qr_scanner.scan(image_path)

    def test_scan_and_decode(self):
        
        # Arrange
        ## Encode test image. (hayden.jpg)
        qr_path = "./tests/testing_resources/test_qr_scanner.svg"
        face_scanner = FaceScanner()
        autoencoder = Autoencoder()
        qr_printer = QRPrinter()
        qr_scanner = QRScanner.get_scanner("zxing-https")
        image_path = "/home/ssierra/Projects/secureQRFacing/tests/testing_resources/hayden.jpg"

        # Get the face embeddings

        faces = face_scanner.scan(image_path)[0]
        reduced_faces = autoencoder.encode(faces)
        expected = autoencoder.predict(faces)

        # Encode the face embeddings

        encoded_bistream = encoder.pack(reduced_faces, decimal_positions=4)

        qr_printer.print(encoded_bistream, qr_path)

        # Read the QR code

        qr_data = qr_scanner.scan(qr_path)
        decoded_faces = decoder.unpack(qr_data, decimal_positions=4)

        # Act

        # Assert
        self.assertEqual(encoded_bistream.hex, qr_data.hex)

if __name__ == '__main__':
    unittest.main()