# This file contains the encoder class for the secureQRFacing module
# The encoder class is responsible for encoding the data so it can be directly
# used by the QR code generator.

import numpy as np
import math
from bitstring import BitArray

LOG2_10 = 3.3219280948873626

def encode(embedding, decimal_positions=3, decimal_separator='.'):
    '''Encodes the embedding into a bitstring list.
    The input embedding is a list of numbers.
    Each number is represented with a fixed number of decimal positions.

    Accepts NumPy arrays.
    
    Preconditions: decimal_positions > 0.
    Strings are not accepted as input. Use encode_from_string instead.
    '''
    encoded_embedding = []
    for index, elem in enumerate(embedding):
        encoded_embedding.append(
            encode_component(elem, decimal_positions=decimal_positions,
                                        decimal_separator=decimal_separator, component_index=index)
        )
    
    return encoded_embedding

def encode_from_string(str_embedding : str, decimal_positions=3, decimal_separator=".", element_separator=","):
    '''Encodes the embedding into a bitstring.
    The input embedding is a string of comma separated numbers.
    Each number is represented with a fixed number of decimal positions.

    Preconditions: decimal_positions > 0.
    '''
    encoded_embedding = []
    for index, elem in enumerate(str_embedding.replace('[', '').replace(']', '').split(element_separator)):
        encoded_embedding.append(
            encode_component_from_string(elem, decimal_positions=decimal_positions,
                                        decimal_separator=decimal_separator, component_index=index)
        )
    
    return encoded_embedding

def join(embedding : list):
    '''Joins a list of encoded components into a single bitstring.'''
    return BitArray().join(embedding)

def encode_component(number, decimal_positions=3, decimal_separator='.', component_index=0) -> BitArray:
    '''Encodes a component of the embedding into a bitstring.
    The input component is a number with a decimal part.
    The decimal part is represented with a fixed number of decimal positions.

    Preconditions: number in (-1,1) and decimal_positions > 0.
    '''
    return encode_component_from_string(str(number), decimal_positions=decimal_positions,
                                        decimal_separator=decimal_separator, component_index=component_index)

def encode_component_from_string(str_component : str, decimal_positions=3, decimal_separator=".", component_index=0) -> BitArray:
    '''Encodes a component of the embedding into a bitstring.
    The input component is a string representing a number with a decimal part.
    The decimal part is represented with a fixed number of decimal positions.

    Preconditions: str_component in (-1,1) and decimal_positions > 0.
    '''

    ## Convert the string-represented number into a float.
    float_component = float(str_component.replace(decimal_separator, '.').replace(' ', ''))
    is_negative = float_component < 0
    float_component = abs(float_component)


    number = int((float_component % 1)*10**decimal_positions) # Decimal part to be encoded.
    integer_part = int(float_component)

    # Get the needed number of bytes to represent the number.
    min_needed_bits = math.ceil(LOG2_10 * decimal_positions)
    needed_bytes = math.ceil(min_needed_bits/8)
    # Get decimal part of the number and format accordingly.

    
    sign = BitArray('0b0')
    if is_negative:
        sign = BitArray('0b1')

    one = BitArray('0b0')
    if integer_part:

        if integer_part != 1: raise ValueError("The integer part of the number must be 1 or -1.")

        number = component_index
        one = BitArray('0b1')
        
    bitstring = BitArray(uint=number, length=min_needed_bits)
    
    return BitArray(one) + sign + bitstring

def to_int_list(bitstring : BitArray):
    '''Converts a bitstring into a list of integers.'''
    return [x.uint for x in bitstring.cut(8)]

def pack(embedding: list, decimal_positions=3, decimal_separator='.', float_length = 32) -> BitArray:
    """
    This method receives an autoencoder-encoded embedding, normalises it and packs it into a 
    stream of raw bits.
    Norm of the input embedding is calculated and appended to the beginning of the bitstream
    as a float with @float_length bits.

    Preconditions: decimal_positions > 0.
    Strings are not accepted as input. Use pack_from_string instead.
    """
    embedding = np.array(embedding).flatten()

    # Normalise the embedding
    norm = np.linalg.norm(embedding)
    normalised_embedding = embedding / norm

    # Encode the normalised embedding
    encoded_embedding = encode(normalised_embedding, decimal_positions=decimal_positions, decimal_separator=decimal_separator)

    # Join the encoded embedding
    bitstream = join(encoded_embedding)
    return BitArray(float=norm, length=float_length) + bitstream

def pack_from_string(str_embedding : str, decimal_positions=3, decimal_separator=".", element_separator=",", float_length = 32) -> BitArray:
    """
    This method receives an autoencoder-encoded embedding, normalises it and packs it into a
    stream of raw bits.
    Norm of the input embedding is calculated and appended to the beginning of the bitstream
    as a float with @float_length bits.

    Preconditions: decimal_positions > 0.
    Input must be a string.
    """

    embedding = np.array([float(x) for x in str_embedding.replace('[', '').replace(']', '').split(element_separator)]).flatten()

    # Normalise the embedding
    norm = np.linalg.norm(embedding)
    normalised_embedding = embedding / norm

    # Encode the normalised embedding
    encoded_embedding = encode(normalised_embedding, decimal_positions=decimal_positions, decimal_separator=decimal_separator)

    # Join the encoded embedding
    bitstream = join(encoded_embedding)
    return BitArray(float=norm, length=float_length) + bitstream
