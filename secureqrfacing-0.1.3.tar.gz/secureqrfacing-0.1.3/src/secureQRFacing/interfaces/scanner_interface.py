# This file defines an interface for the scanner module.
# This module is responsible for defining operations on image
# scanning and processing.

from abc import ABC, abstractmethod

class ScannerInterface(ABC):

    def __init__(self, image_path: str):
        pass

    @abstractmethod
    def init_backend(self, model: str):
        '''Attaches the model to the scanner.
        '''
        pass

    @abstractmethod
    def scan(self, image_path: str, verbose: int):
        '''Scans the image at the given path.
        Returns the read data.
        '''
        pass

    @abstractmethod
    def process(self, data) -> str:
        '''Processes the image at the given path.
        Returns the processed image.
        '''
        pass