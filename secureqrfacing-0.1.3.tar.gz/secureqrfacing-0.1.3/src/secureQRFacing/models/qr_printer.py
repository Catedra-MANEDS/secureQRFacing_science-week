from ..interfaces.printer_interface import PrinterInterface
from .. import decoder

class QRPrinter(PrinterInterface):

    def __init__(self):
        self.init_backend()

    def init_backend(self):
        '''Initializes the backend for the printer.
        '''
        import qrcode
        from qrcode.image.svg import SvgImage

        self.backend = [qrcode, SvgImage]

    def print(self, data, path: str,
            version: int = 0, error_correction: str = 'H', verbose: bool = False) -> None:
        '''Writes the data into a QR code at the given path.
        Expects either a BitArray or a list of integers as input.
        '''

        #####################
        ## Input shielding ##
        #####################

        # Get error correction level
        if error_correction == 'L':
            error_correction = self.backend[0].constants.ERROR_CORRECT_L
        elif error_correction == 'M':
            error_correction = self.backend[0].constants.ERROR_CORRECT_M
        elif error_correction == 'Q':
            error_correction = self.backend[0].constants.ERROR_CORRECT_Q
        elif error_correction == 'H':
            error_correction = self.backend[0].constants.ERROR_CORRECT_H
        else:
            error_correction = 'H'

        if version == 0 or version > 40:
            version = None

        if isinstance(data, list) and isinstance(data[0], int):
            data = decoder.decode_into_bitarray(data)
        
        data = data.bytes

        #########################
        ## End input shielding ##
        #########################

        
        # This is the original code
        # Implemented using qrcode library
        
        
        qr = self.backend[0].QRCode(
            version=version,
            error_correction=error_correction,
        )

        qr.add_data(data)

        qr.make(fit=True)


        # Create an image instance
        img = qr.make_image(image_factory=self.backend[1])

        # Save the image
        img.save(path)
        
        if verbose: print(f'QR Printed | Version: {qr.version}, Error Correction: {error_correction}')
