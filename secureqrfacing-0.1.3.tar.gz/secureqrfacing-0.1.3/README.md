# secureQRFacing

secureQRFacing is a Python library for secure and efficient processing of QR codes in the context of facial recognition applications. It provides functions for representing facial data as QR codes, generating QR codes from facial images, and retrieving facial data from QR codes.

## Installation

secureQRFacing is not yet available on PyPI, but you can install it from GitHub using pip:

1. **Download the `.whl` file**:
    - Access the latest review of the secureQRFacing library.
    - Look for the `.whl` file in the assets or downloads section of the review.
    - Download the `.whl` file to your local machine/project.

2. **Install the `.whl` file using pip**:
    - Open a terminal or command prompt.
    - Navigate to the directory where the `.whl` file is located.
    - Run the following command to install the `.whl` file:
        ```bash
        pip install secureQRFacing-X.Y.Z-py3-none-any.whl
        ```
        Replace `secureQRFacing-X.Y.Z-py3-none-any.whl` with the actual name of the downloaded `.whl` file.

3. **Verify installation**:

    After installation is complete, you can verify that the library is installed by running:

    ```bash
    pip list
    ```
    Look for **secureQRFacing** in the list of installed packages.

4. **Import and use the library**:

    You can now import the library in your Python scripts and use its functionality as needed.

    That's it! You have successfully downloaded and installed the secureQRFacing library from the latest review using the .whl file.

## Core API Functions

### Represent

The `represent` function generates a QR code from a facial image, encoding either the face embedding directly or in its latent representation. It supports different stages of the encoding process, allowing customisation based on specific requirements.

### Generate
The `generate` function generates a QR code from a facial image, utilizing a backend for face detection and an autoencoder for encoding facial data. It supports customisation of the encoding process, including the number of decimal positions and the length of the float used for encoding.

### Retrieve
The `retrieve` function retrieves the facial embedding from a QR code image. It supports decoding of both latent and non-latent representations and allows customisation of the decoding process.

## Usage

Here's a simple example of how to use the secureQRFacing library to generate a QR code from a facial image and retrieve the facial data from the QR code:

```python
from secureQRFacing.secureqrfacing import SecureQRFacing as sqf

# Generate a QR code from a facial image
image_path = "path_to_image.jpg"
qr_path = "path_to_save_qr.png"

qr_code = sqf.generate(image_path, qr_path)

# Retrieve facial data from the QR code

retrieved_data = sqf.retrieve(qr_path)
print(retrieved_data)
```

If we only needed, for instance, to get the latent representation of the facial data, we could use the `represent` function instead of the `generate` function:

```python
from secureQRFacing.secureqrfacing import SecureQRFacing as sqf

# Represent embedding in latent space.

image_path = "path_to_image.jpg"
latent_representation = sqf.represent(image_path, stage=1)
print(latent_representation)
```

## Documentation

To be added.

## Contributing

Contributions are welcome! If you encounter any issues, have feature requests, or would like to contribute code, please don't hesitate to **create an issue** or **submit a pull request**.


