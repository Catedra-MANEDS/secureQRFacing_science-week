# This file implements a wrapper around the facenet model
# implemented in the Seren Gil's DeepFace library.
# https://github.com/serengil/deepface

from ..interfaces.scanner_interface import ScannerInterface
import numpy as np

class FaceScanner(ScannerInterface):

    def __init__(self):
        self.init_backend()

    def init_backend(self):

        from deepface import DeepFace
        self.model = DeepFace

    def scan(self, image_path: str, backend: str="Facenet", verbose: int = 0,
            embedding_only = True, normalise =  True) -> list:
        """
        Scans the image at the given path using the specified backend.
        Detects the faces within the image and returns their embeddings.

        Args:
        - image_path: The path to the image to be scanned.
        - backend: The backend to be used for scanning. Defaults to "Facenet".
        - verbose: The verbosity of the scanning process. Defaults to 0.

        Returns:
        - A list of dictionaries containing the detected faces and their embeddings.
            - embedding: The embedding of the detected face.
            - face_region: The region (rect) of the face in the image.
            - facial_confidence: The confidence of the detection.
        """

        models = [
            "VGG-Face", 
            "Facenet", 
            "Facenet512", 
            "OpenFace", 
            "DeepFace", 
            "DeepID", 
            "ArcFace", 
            "Dlib", 
            "SFace",
            ]

        if backend not in models:
            raise ValueError(f"Invalid model name. Choose one of the following: {models}")
        
        result = self.model.represent(image_path, model_name=backend)
        
        if normalise:
            for face in result:
                face['embedding'] = np.array(face['embedding'])/np.linalg.norm(face['embedding'])

        if embedding_only: result = [np.array(face['embedding']) for face in result]

        if verbose:
            print(f"Scanning image at {image_path} with {backend} model.")
            for detection in result:
                for key, value in detection.items():
                    print(f"{key}: {value}")

        return result


    
    def process(self) -> str:
        return super().process()