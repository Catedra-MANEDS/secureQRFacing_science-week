import unittest
import sys
import os

sys.path.append('/home/ssierra/Projects/secureQRFacing/src')
from secureQRFacing.models.qr_printer import QRPrinter
from secureQRFacing import encoder

class TestQRPrinter(unittest.TestCase):

    def test_print_from_int_list(self):
        # Arrange
        data = [-0.325, 0.021, 0.4, -0.004104567, 0.0001, -1.456, 1.53, -0.52,
                0.0, 0.56, 0.89, -0.7, -0.456753, 0.1234, 0.78, -0.2]
        path = 'tests/testing_resources/test_list.svg'

        # Act
        payload = encoder.to_int_list(encoder.pack(data, float_length=32, decimal_positions=3))
        printer = QRPrinter()
        printer.print(payload, path, version=3, error_correction='Q')

        # Assert
        self.assertTrue(True)

    def test_print_from_bitarray(self):
        # Arrange
        data = [-0.325, 0.021, 0.4, -0.004104567, 0.0001, -1.456, 1.53, -0.52,
                0.0, 0.56, 0.89, -0.7, -0.456753, 0.1234, 0.78, -0.2]
        path = 'tests/testing_resources/test_bitarray.svg'

        # Act
        payload = encoder.pack(data, float_length=32, decimal_positions=3)
        printer = QRPrinter()
        printer.print(payload, path, version=3, error_correction='Q')

        # Assert

        ## This is a void method, so we can only check that it does not raise an error.
        self.assertTrue(True)

    def test_output_is_equal_from_int_list_and_bitarray(self):
        # Arrange
        path_int_list = 'tests/testing_resources/test_list.svg'
        path_bitarray = 'tests/testing_resources/test_bitarray.svg'

        # Act
        # Compare the two files
        with open(path_int_list, 'r') as file1:
            with open(path_bitarray, 'r') as file2:
                # Assert
                self.assertEqual(file1.read(), file2.read())

if __name__ == '__main__':
    unittest.main()

